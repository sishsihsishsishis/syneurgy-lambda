// index.mjs

import stripe from "stripe";

import * as configEnv from './config.mjs';
import * as queryFunction from './query.mjs';
import * as utils from './utils.mjs';

const stripeInstance = stripe(configEnv.stripeSecretKey);

export const handler = async (event) => {
  const client = utils.parseAndCheckHttpError(await utils.getDBInstance());

  try {
    // CORS Preflight
    if (event?.requestContext?.http?.method === 'OPTIONS') {
      return {
        statusCode: 200,
        headers: configEnv.headers,
        body: '',
      };
    }

    // Get token email (current user)
    const email = utils.parseAndCheckHttpError(await utils.getTokenEmail(event));

    // Check if you are the administrator or provider of this license
    const subscription = await queryFunction.subscriptions(
      client, 
      { command: 'get-subscription-by-user_email',
        filters: { user_email: email }
      }
    );
    const subscriptionData = subscription?.rows[0];

    if (!subscriptionData) {
      return {
        statusCode: 400,
        headers: configEnv.headers,
        body: JSON.stringify({ email, error: 'You do not have permission for this resource.' }),
      };
    }

    let message = 'the subscription does not have a free trial period.'
    const subscriptionStripe = await stripeInstance.subscriptions.retrieve(subscriptionData.stripe_data.subscription.id);

    if (subscriptionStripe.trial_end !== null) {
      await stripeInstance.subscriptions.update(subscriptionData.stripe_data.subscription.id, {
        trial_end: 'now',
      });

      message = 'free trial period removed successfully.';
    }
    
    const response = {
      statusCode: 200,
      headers: configEnv.headers,
      body: JSON.stringify({ message }),
    };

    return response;
  } catch (error) {
    return {
      statusCode: error?.details?.statusCode || 500,
      headers: configEnv.headers,
      body: JSON.stringify(error?.details?.body || { error: 'Internal Server Error.' }),
    };
  } finally {
    await client.end();
  }
};
